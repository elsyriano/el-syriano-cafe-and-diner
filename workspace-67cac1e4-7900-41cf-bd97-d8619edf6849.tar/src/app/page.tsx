"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  MapPin,
  Phone,
  Clock,
  Facebook,
  Instagram,
  ChevronDown,
  Menu,
  X,
  Star,
  Users,
  PartyPopper,
  Coffee,
  UtensilsCrossed,
  ArrowUp,
} from "lucide-react";
import { getMenuCategories, getCategoryNames } from "@/lib/menu-data";
import type { MenuCategory } from "@/lib/menu-data";

/* ─────────────────────── Navigation ─────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Menu", href: "#menu" },
    { label: "Party Trays", href: "#party" },
    { label: "Find Us", href: "#location" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-lg py-2"
          : "bg-transparent py-4"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-3 group">
          <div className="relative w-11 h-11 rounded-full overflow-hidden border-2 border-gold/50 group-hover:border-gold transition-colors">
            <Image
              src="/images/logo.jpg"
              alt="El Syriano Logo"
              fill
              className="object-cover"
              sizes="44px"
            />
          </div>
          <div className="flex flex-col">
            <span
              className={`font-[family-name:var(--font-playfair)] text-lg font-bold leading-tight transition-colors ${
                scrolled ? "text-warm-dark" : "text-white"
              }`}
            >
              El Syriano
            </span>
            <span
              className={`text-[10px] uppercase tracking-[0.2em] transition-colors ${
                scrolled ? "text-gold" : "text-gold-light"
              }`}
            >
              Cafe & Diner
            </span>
          </div>
        </a>

        {/* Desktop links */}
        <div className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className={`text-sm font-medium tracking-wide uppercase transition-colors hover:text-gold ${
                scrolled ? "text-warm-dark" : "text-white"
              }`}
            >
              {l.label}
            </a>
          ))}
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? (
            <X className={scrolled ? "text-warm-dark" : "text-white"} size={24} />
          ) : (
            <Menu className={scrolled ? "text-warm-dark" : "text-white"} size={24} />
          )}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white/95 backdrop-blur-md shadow-lg border-t border-gold/10 overflow-hidden"
          >
            <div className="px-6 py-4 flex flex-col gap-3">
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setMobileOpen(false)}
                  className="text-sm font-medium tracking-wide uppercase text-warm-dark hover:text-gold py-2 border-b border-gray-100 transition-colors"
                >
                  {l.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

/* ─────────────────────── Hero ─────────────────────── */
function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <Image
        src="/images/hero-bg.jpg"
        alt="El Syriano Cafe interior"
        fill
        className="object-cover"
        priority
        sizes="100vw"
      />
      {/* Overlay */}
      <div className="absolute inset-0 hero-gradient" />

      {/* Decorative top & bottom borders */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <div className="ornament-divider text-gold mb-6">
            <Star size={16} />
          </div>
          <h1 className="font-[family-name:var(--font-playfair)] text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white leading-tight mb-4">
            El Syriano
          </h1>
          <p className="text-gold-light text-lg sm:text-xl md:text-2xl uppercase tracking-[0.25em] mb-3 font-light">
            Cafe & Diner
          </p>
          <p className="text-white/80 text-base sm:text-lg md:text-xl mt-6 max-w-2xl mx-auto font-light leading-relaxed">
            Experience the Zest of the Mediterranean
          </p>
          <p className="text-white/60 text-sm sm:text-base mt-3 max-w-xl mx-auto">
            Authentic Middle Eastern &amp; Arabic cuisine in the heart of Tayug, Pangasinan
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
          className="mt-10 flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Button
            asChild
            size="lg"
            className="bg-gold hover:bg-gold-light text-warm-dark font-semibold px-8 py-6 text-base uppercase tracking-wider rounded-none"
          >
            <a href="#menu">View Our Menu</a>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-white/40 text-white hover:bg-white/10 hover:text-white px-8 py-6 text-base uppercase tracking-wider rounded-none"
          >
            <a href="#location">Find Us</a>
          </Button>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <a href="#about" className="flex flex-col items-center gap-2 text-white/50 hover:text-gold transition-colors">
            <span className="text-xs uppercase tracking-widest">Scroll</span>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <ChevronDown size={20} />
            </motion.div>
          </a>
        </motion.div>
      </div>
    </section>
  );
}

/* ─────────────────────── About ─────────────────────── */
function About() {
  const features = [
    {
      icon: UtensilsCrossed,
      title: "Authentic Middle Eastern",
      desc: "From aromatic Shawarma and Kabsa Biryani to traditional Hummus and Baklava — every dish is crafted with heritage recipes and passion.",
    },
    {
      icon: Coffee,
      title: "Premium Coffee Bar",
      desc: "Savor expertly brewed Spanish Latte, French Vanilla, Hazelnut, Matcha, and more. Hot, iced, or blended to perfection.",
    },
    {
      icon: Users,
      title: "Pinoy Favorites Too",
      desc: "We also celebrate local flavors with Bulalo, Sisig, Lechon Kawali, Sinigang, and other beloved Filipino comfort dishes.",
    },
    {
      icon: PartyPopper,
      title: "Party Trays Available",
      desc: "Hosting a gathering? Choose from our generous party trays and ultimate feast packages — perfect for celebrations of any size.",
    },
  ];

  return (
    <section id="about" className="py-20 md:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-gold uppercase tracking-[0.2em] text-sm font-medium">Our Story</span>
          <h2 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl md:text-5xl font-bold text-warm-dark mt-3">
            A Taste of the Mediterranean
          </h2>
          <div className="ornament-divider max-w-xs mx-auto mt-4">
            <Star size={14} className="text-gold" />
          </div>
        </div>

        {/* About content */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div className="relative rounded-xl overflow-hidden shadow-2xl aspect-[4/3]">
            <Image
              src="/images/food-platter.jpg"
              alt="El Syriano Mediterranean platter"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-warm-dark/30 to-transparent" />
          </div>
          <div className="space-y-6">
            <p className="text-muted-foreground text-lg leading-relaxed">
              Welcome to <strong className="text-warm-dark">El Syriano Cafe &amp; Diner</strong>, a culinary gem
              nestled in Tayug, Pangasinan. We bring the rich and vibrant flavors of the
              Mediterranean and Middle East to your table, blending them seamlessly with
              beloved Filipino favorites.
            </p>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Located on Rizal Street, just beside the historic St. Patrick of Ireland Parish
              Church, our cafe offers a warm and inviting atmosphere where every visit feels
              like a celebration. Whether you&#39;re craving authentic Arabic Kabsa Biryani, a
              hearty Beef Shawarma, or a comforting cup of Spanish Latte, we have something
              special waiting for you.
            </p>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Rated <strong className="text-gold">5.0 on TripAdvisor</strong> and loved by locals
              and travelers alike, El Syriano is more than just a restaurant — it&#39;s a place
              where great food, wonderful people, and memorable moments come together.
            </p>
            <div className="flex gap-4 pt-2">
              <Badge className="bg-gold/10 text-gold border-gold/20 px-4 py-1.5 text-sm">
                <Star className="w-3.5 h-3.5 mr-1 fill-gold" />
                5.0 Rating
              </Badge>
              <Badge className="bg-olive/10 text-olive border-olive/20 px-4 py-1.5 text-sm">
                <UtensilsCrossed className="w-3.5 h-3.5 mr-1" />
                160+ Menu Items
              </Badge>
            </div>
          </div>
        </div>

        {/* Feature cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <Card
              key={i}
              className="border-gold/10 hover:border-gold/30 hover:shadow-lg transition-all duration-300 group bg-cream/50"
            >
              <CardContent className="p-6 text-center">
                <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-gold/20 transition-colors">
                  <f.icon className="w-7 h-7 text-gold" />
                </div>
                <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-2">
                  {f.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Menu ─────────────────────── */
function MenuSection() {
  const categories = getMenuCategories();
  const categoryNames = getCategoryNames();

  // Remove "Party Trays" from regular menu (has its own section)
  const regularCategories = categories.filter(
    (c) => c.name !== "Party Trays"
  );
  const regularNames = categoryNames.filter((n) => n !== "Party Trays");

  const [activeCategory, setActiveCategory] = useState<string>("All");

  const filteredCategories: MenuCategory[] =
    activeCategory === "All"
      ? regularCategories
      : regularCategories.filter((c) => c.name === activeCategory);

  return (
    <section id="menu" className="py-20 md:py-28 bg-cream/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-gold uppercase tracking-[0.2em] text-sm font-medium">Discover</span>
          <h2 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl md:text-5xl font-bold text-warm-dark mt-3">
            Our Menu
          </h2>
          <div className="ornament-divider max-w-xs mx-auto mt-4">
            <Star size={14} className="text-gold" />
          </div>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto text-base">
            From Mediterranean classics to Filipino comfort food, explore our extensive menu crafted with passion and the finest ingredients.
          </p>
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          <Button
            variant={activeCategory === "All" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveCategory("All")}
            className={
              activeCategory === "All"
                ? "bg-warm-dark text-white hover:bg-warm-dark/90 rounded-full px-5"
                : "rounded-full px-5 border-gold/30 text-warm-dark hover:bg-gold/10 hover:text-gold"
            }
          >
            All
          </Button>
          {regularNames.map((cat) => (
            <Button
              key={cat}
              variant={activeCategory === cat ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat)}
              className={
                activeCategory === cat
                  ? "bg-warm-dark text-white hover:bg-warm-dark/90 rounded-full px-5"
                  : "rounded-full px-5 border-gold/30 text-warm-dark hover:bg-gold/10 hover:text-gold"
              }
            >
              {cat}
            </Button>
          ))}
        </div>

        {/* Menu grid */}
        <div className="space-y-10">
          {filteredCategories.map((category) => (
            <div key={category.name}>
              <div className="flex items-center gap-3 mb-5">
                <Separator className="flex-1 bg-gold/20" />
                <h3 className="font-[family-name:var(--font-playfair)] text-xl font-bold text-warm-dark whitespace-nowrap">
                  {category.name}
                </h3>
                <Separator className="flex-1 bg-gold/20" />
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {category.items.map((item) => (
                  <MenuCard key={item.name} name={item.name} price={item.price} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function MenuCard({ name, price }: { name: string; price: number }) {
  return (
    <Card className="border-gold/10 hover:border-gold/30 hover:shadow-md transition-all duration-200 group">
      <CardContent className="p-4 flex items-center justify-between">
        <span className="text-warm-dark text-sm font-medium group-hover:text-gold transition-colors leading-snug">
          {name}
        </span>
        <span className="text-gold font-bold text-sm whitespace-nowrap ml-3">
          &#8369;{price}
        </span>
      </CardContent>
    </Card>
  );
}

/* ─────────────────────── Party Trays ─────────────────────── */
function PartyTrays() {
  const partyCategory = getMenuCategories().find(
    (c) => c.name === "Party Trays"
  );

  if (!partyCategory) return null;

  return (
    <section id="party" className="py-20 md:py-28 bg-warm-dark text-white relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-gold blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-terracotta blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-gold uppercase tracking-[0.2em] text-sm font-medium">Celebrate</span>
          <h2 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl md:text-5xl font-bold text-white mt-3">
            Party Trays &amp; Feasts
          </h2>
          <div className="ornament-divider max-w-xs mx-auto mt-4">
            <Star size={14} className="text-gold" />
          </div>
          <p className="text-white/60 mt-4 max-w-xl mx-auto text-base">
            Hosting a celebration? Our generous party trays and ultimate feast packages are perfect for gatherings of any size.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {partyCategory.items.map((item) => {
            const isUltimate = item.name.toLowerCase().includes("ultimate");
            return (
              <Card
                key={item.name}
                className={`border transition-all duration-200 hover:shadow-lg ${
                  isUltimate
                    ? "border-gold/50 bg-gold/10 hover:bg-gold/15"
                    : "border-white/10 hover:border-gold/30 bg-white/5 hover:bg-white/10"
                }`}
              >
                <CardContent className="p-4 flex items-center justify-between">
                  <span
                    className={`text-sm font-medium leading-snug ${
                      isUltimate ? "text-gold font-bold" : "text-white/80"
                    }`}
                  >
                    {item.name}
                    {isUltimate && (
                      <span className="ml-2 inline-block px-2 py-0.5 bg-gold/20 text-gold text-[10px] uppercase tracking-wider rounded-full">
                        Best Value
                      </span>
                    )}
                  </span>
                  <span className="text-gold font-bold text-sm whitespace-nowrap ml-3">
                    &#8369;{item.price.toLocaleString()}
                  </span>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-10">
          <p className="text-white/50 text-sm">
            For custom party tray orders and special requests, please contact us directly.
          </p>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Location ─────────────────────── */
function Location() {
  return (
    <section id="location" className="py-20 md:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-gold uppercase tracking-[0.2em] text-sm font-medium">Visit Us</span>
          <h2 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl md:text-5xl font-bold text-warm-dark mt-3">
            Find Us
          </h2>
          <div className="ornament-divider max-w-xs mx-auto mt-4">
            <Star size={14} className="text-gold" />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-10 items-start">
          {/* Map embed */}
          <div className="rounded-xl overflow-hidden shadow-2xl border border-gold/10 aspect-square md:aspect-auto md:min-h-[450px]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3837.5!2d120.7365!3d16.0375!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTbCsDAyJzE1LjAiTiAxMjDCsDQ0JzExLjQiRQ!5e0!3m2!1sen!2sph!4v1!5m2!1sen!2sph&q=El+Syriano+Cafe+and+Diner+Tayug+Pangasinan"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: "450px" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="El Syriano Cafe & Diner Location"
            />
          </div>

          {/* Location details */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-1">
                    Our Address
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    1 Rizal St. Poblacion A, Tayug, Pangasinan
                    <br />
                    <span className="text-sm">
                      (In front of Tayug Water District, beside St. Patrick of Ireland Parish Church; adjacent to Magic Mall)
                    </span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-1">
                    Call or Text
                  </h3>
                  <a
                    href="tel:+639289765638"
                    className="text-muted-foreground hover:text-gold transition-colors text-lg"
                  >
                    +63 928 976 5638
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-1">
                    Opening Hours
                  </h3>
                  <p className="text-muted-foreground">Open Daily: 9:00 AM – 9:00 PM</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Kitchen closes 30 minutes before closing time
                  </p>
                </div>
              </div>
            </div>

            <Separator className="bg-gold/20" />

            <div>
              <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-3">
                How to Find Us
              </h3>
              <ul className="space-y-3 text-muted-foreground text-sm leading-relaxed">
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-gold/20 flex items-center justify-center shrink-0 mt-0.5 text-gold text-xs font-bold">1</span>
                  Head to Rizal Street in Poblacion A, Tayug, Pangasinan
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-gold/20 flex items-center justify-center shrink-0 mt-0.5 text-gold text-xs font-bold">2</span>
                  Look for the Tayug Water District office — we are directly in front
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-gold/20 flex items-center justify-center shrink-0 mt-0.5 text-gold text-xs font-bold">3</span>
                  We are beside St. Patrick of Ireland Parish Church, adjacent to Magic Mall
                </li>
              </ul>
            </div>

            <div className="flex gap-3">
              <Button asChild className="bg-gold hover:bg-gold-light text-warm-dark font-semibold rounded-none">
                <a
                  href="https://maps.app.goo.gl/mVGVKuJVQKV7gYXE8"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  Get Directions
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Contact ─────────────────────── */
function Contact() {
  return (
    <section id="contact" className="py-20 md:py-28 bg-cream/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-gold uppercase tracking-[0.2em] text-sm font-medium">Get in Touch</span>
          <h2 className="font-[family-name:var(--font-playfair)] text-3xl sm:text-4xl md:text-5xl font-bold text-warm-dark mt-3">
            Contact Us
          </h2>
          <div className="ornament-divider max-w-xs mx-auto mt-4">
            <Star size={14} className="text-gold" />
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <Card className="text-center border-gold/10 hover:border-gold/30 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-8">
              <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-gold" />
              </div>
              <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-2">
                Phone
              </h3>
              <a
                href="tel:+639289765638"
                className="text-muted-foreground hover:text-gold transition-colors"
              >
                +63 928 976 5638
              </a>
              <p className="text-sm text-muted-foreground/70 mt-1">
                Call or text us for orders and inquiries
              </p>
            </CardContent>
          </Card>

          <Card className="text-center border-gold/10 hover:border-gold/30 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-8">
              <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4">
                <Facebook className="w-8 h-8 text-gold" />
              </div>
              <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-2">
                Facebook
              </h3>
              <a
                href="https://www.facebook.com/profile.php?id=100091311893297"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-gold transition-colors"
              >
                El Syriano Tayug
              </a>
              <p className="text-sm text-muted-foreground/70 mt-1">
                Follow us for updates and promos
              </p>
            </CardContent>
          </Card>

          <Card className="text-center border-gold/10 hover:border-gold/30 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-8">
              <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4">
                <Instagram className="w-8 h-8 text-gold" />
              </div>
              <h3 className="font-[family-name:var(--font-playfair)] text-lg font-bold text-warm-dark mb-2">
                Instagram
              </h3>
              <a
                href="https://www.instagram.com/explore/locations/107759048951411"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-gold transition-colors"
              >
                @elsyrianotayug
              </a>
              <p className="text-sm text-muted-foreground/70 mt-1">
                Tag us in your food photos!
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Footer ─────────────────────── */
function Footer() {
  return (
    <footer className="bg-warm-dark text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-10 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-10 h-10 rounded-full overflow-hidden border border-gold/30">
                <Image
                  src="/images/logo.jpg"
                  alt="El Syriano Logo"
                  fill
                  className="object-cover"
                  sizes="40px"
                />
              </div>
              <div>
                <span className="font-[family-name:var(--font-playfair)] text-lg font-bold">
                  El Syriano
                </span>
                <span className="block text-gold text-[10px] uppercase tracking-[0.2em]">
                  Cafe & Diner
                </span>
              </div>
            </div>
            <p className="text-white/50 text-sm leading-relaxed">
              Experience the Zest of the Mediterranean. Authentic Middle Eastern and
              Arabic cuisine in the heart of Tayug, Pangasinan.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-[family-name:var(--font-playfair)] text-base font-bold mb-4 text-gold">
              Quick Links
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Home", href: "#home" },
                { label: "About", href: "#about" },
                { label: "Menu", href: "#menu" },
                { label: "Party Trays", href: "#party" },
                { label: "Find Us", href: "#location" },
                { label: "Contact", href: "#contact" },
              ].map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-white/50 hover:text-gold transition-colors text-sm py-1"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-[family-name:var(--font-playfair)] text-base font-bold mb-4 text-gold">
              Contact Info
            </h4>
            <div className="space-y-3 text-white/50 text-sm">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 shrink-0 mt-0.5 text-gold" />
                1 Rizal St. Poblacion A, Tayug, Pangasinan
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 shrink-0 text-gold" />
                <a href="tel:+639289765638" className="hover:text-gold transition-colors">
                  +63 928 976 5638
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 shrink-0 text-gold" />
                Open Daily: 9:00 AM – 9:00 PM
              </p>
            </div>
            <div className="flex gap-3 mt-5">
              <a
                href="https://www.facebook.com/profile.php?id=100091311893297"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-gold/20 flex items-center justify-center transition-colors"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://www.instagram.com/explore/locations/107759048951411"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-gold/20 flex items-center justify-center transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        <Separator className="bg-white/10 mb-6" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-white/30 text-xs">
            &copy; {new Date().getFullYear()} El Syriano Cafe &amp; Diner. All rights reserved.
          </p>
          <p className="text-white/30 text-xs">
            Tayug, Pangasinan, Philippines
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────── Scroll to Top ─────────────────────── */
function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 500);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 w-12 h-12 rounded-full bg-warm-dark text-white shadow-lg hover:bg-gold hover:text-warm-dark transition-colors flex items-center justify-center"
          aria-label="Scroll to top"
        >
          <ArrowUp className="w-5 h-5" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}

/* ─────────────────────── Page ─────────────────────── */
export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <About />
      <MenuSection />
      <PartyTrays />
      <Location />
      <Contact />
      <Footer />
      <ScrollToTop />
    </main>
  );
}
