import type { Metadata } from "next";
import { Playfair_Display, Lato } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  display: "swap",
});

const lato = Lato({
  variable: "--font-lato",
  subsets: ["latin"],
  weight: ["300", "400", "700", "900"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "El Syriano Cafe & Diner | Mediterranean & Arabic Cuisine in Tayug",
  description:
    "Experience the Zest of the Mediterranean at El Syriano Cafe & Diner. Serving authentic Middle Eastern dishes, Arabic Kabsa Biryani, Shawarma, Tawook Wraps, and more in Tayug, Pangasinan.",
  keywords: [
    "El Syriano",
    "Mediterranean food",
    "Arabic food",
    "Shawarma",
    "Biryani",
    "Tayug restaurant",
    "Pangasinan restaurant",
    "Middle Eastern cuisine",
    "Cafe and Diner",
  ],
  icons: {
    icon: "/images/logo.jpg",
  },
  openGraph: {
    title: "El Syriano Cafe & Diner",
    description:
      "Experience the Zest of the Mediterranean. Authentic Middle Eastern dishes in Tayug, Pangasinan.",
    siteName: "El Syriano Cafe & Diner",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${playfair.variable} ${lato.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
